<?php
/**
 * 404 Page Template.
 *
 * @package ATS
 */

$page_title       = get_field( '404_title', 'option' );
$page_subline     = get_field( '404_subline', 'option' );
$page_discription = get_field( '404_discription', 'option' );
?>
<section class="error-404 top-space-margin">
	<div class="container">
		<div class="row justify-content-center text-center">
			<div class="col-12 not-found">
				<div class="small-title"><?php echo $page_subline; //phpcs:ignore ?></div>
				<h1 class="title"><?php echo $page_title; //phpcs:ignore ?></h1>
				<p class="description"><?php echo $page_discription; //phpcs:ignore ?></p>
				<a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html__( 'Back to homepage', 'ats' ); ?></a>
			</div>
		</div>
	</div>
</section>
