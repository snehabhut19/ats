<?php
/**
 * Template name: Team Page
 *
 * @package ATS/var/www/html/ats/wp-content/themes/ats/acf-json/var/www/html/ats/wp-content/themes/ats/acf-json/var/www/html/ats/wp-content/themes/ats/acf-json/var/www/html/ats/wp-content/themes/ats/acf-json/var/www/html/ats/wp-content/themes/ats/acf-json
 */

$have_space = ' top-space-margin';
if ( have_rows( 'page_flexible' ) ) {
	$have_space = '';
	while ( have_rows( 'page_flexible' ) ) :
		the_row();
		$layout_section = get_row_layout();

		switch ( $layout_section ) {
			case 'image_hero_banner':
			case 'homepage_hero_banner':
			case 'services':
			case 'logos':
			case 'infographic_block':
			case 'accordion':
			case 'related_case_studies':
			case 'content_block':
			case 'background_image':
			case 'content_block':
			case 'select_form':
			case 'related_team':
				$template_name = str_replace( '_', '-', $layout_section );
				get_template_part( 'template-parts/acf-flexible/' . $template_name );
				break;
			default:
				break;
		}
	endwhile;
}
?>
<section class="team-listing-block<?php echo $have_space; ?>">
	<div class="container">
		<div class="row">
			<div class="col-12 text-center section-title">
				<?php the_title( '<h2 class="h-5">', '</h2>' ); ?>
			</div>
		</div>
		<?php
		$args = [
			'post_type'      => 'team',
			'order'          => 'DESC',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		];
		$insight_post = new WP_Query( $args );
		?>
		<div class="filter-content">
			<div class="row">
				<div class="col-12">
					<ul class="team-list">
						<?php
						while ( $insight_post->have_posts() ) {
							$insight_post->the_post();
							if ( has_post_thumbnail() ) {
								$select_image = get_the_post_thumbnail();
							} else {
								$select_image = '<img src="' . ATS_AF_THEME_DIR_URI . '/inc/assets/placeholder-image.jpg" />';
							}
							?>
							<li>
								<div class="related-team-details">
									<div class="feature-image">
										<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php echo $select_image; ?></a>
									</div>										
									<div class="related-team-content">
										<?php
										if ( get_the_title() ) {
											?>
											<div class="post-title">
												<?php echo get_the_title(); //phpcs:ignore ?>
											</div>
											<?php
										}
										?>
										<a class="btn secondary white" href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php esc_html_e( 'View profile', 'ats' ); ?></a>
									</div>
								</div>
							</li>
							<?php
						} // end while
						wp_reset_postdata();
						?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
