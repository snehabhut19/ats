<?php
/**
 * Template name: Listing Page
 *
 * @package ATS
 */

$have_space = ' top-space-margin';
if ( have_rows( 'page_flexible' ) ) {
	$have_space = '';
	while ( have_rows( 'page_flexible' ) ) :
		the_row();
		$layout_section = get_row_layout();

		switch ( $layout_section ) {
			case 'image_hero_banner':
			case 'homepage_hero_banner':
			case 'services':
			case 'logos':
			case 'infographic_block':
			case 'accordion':
			case 'related_case_studies':
			case 'content_block':
			case 'background_image':
			case 'content_block':
			case 'select_form':
			case 'related_team':
				$template_name = str_replace( '_', '-', $layout_section );
				get_template_part( 'template-parts/acf-flexible/' . $template_name );
				break;
			default:
				break;
		}
	endwhile;
}
?>
<section class="listing-block<?php echo $have_space; ?>">
	<div class="container">
		<div class="row">
			<div class="col-12 section-title">
				<h2 class="post-category h-5"><?php esc_html_e( 'Case Studies', 'ats' ); ?></h2>
				<h3 class="post-title h-2"><?php esc_html_e( 'Latest Project', 'ats' ); ?></h3>
			</div>
		</div>
		<?php
		$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
		$args = array(
			'post_type'      => 'case-studies',
			'order'          => 'DESC',
			'post_status'    => 'publish',
			'posts_per_page' => 9,
			'paged'          => $paged,
		);
		$insight_post = new WP_Query( $args );	
		?>
		<div class="row">
			<?php
			if ( $insight_post->have_posts() ) {
				?>
				<div class="col-12">
					<?php
					echo '<div class="filter-title">' . esc_html__( 'Filter categories:', 'ats' ) . '</div>';
					$tax_terms = get_terms( 'case-study-cat', array('hide_empty' => false));
						$count = '';
						$i     = 1;
					echo '<div class="auto-scroll"><div class="auto-scroll-warp"><ul class="tabs case-studies-catogories">';
					foreach ( $tax_terms as $term_single ) {
						echo '<li><a class="check-box" data-id="' . $term_single->term_id . '"> ' . $term_single->name . '</a></li>';
						$count = $i++;
					}
					echo '</ul>';
					echo '</div>';
					echo '</div>';
					?>
				</div>
				<?php
			}
			?>
		</div>
		<div class="filter-content">
			<div class="row">
				<div class="col-12 position-relative">
					<div class="spinner"><div class="spinner-speeding"></div></div>
					<ul class="case-studies-list">
						<?php
						while ( $insight_post->have_posts() ) {
							$insight_post->the_post();
							if ( has_post_thumbnail() ) {
								$select_image = get_the_post_thumbnail();
							} else {
								$select_image = '<img src="' . ATS_AF_THEME_DIR_URI . '/inc/assets/placeholder-image.jpg" />';
							}
							?>
							<li>
								<div class="related-case-studies-details">									
									<div class="feature-image">
									<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php echo $select_image; ?></a>
									</div>
										<div class="related-case-studies-content">
										<?php
										$taxonomy_arr = get_the_terms( get_the_ID(), 'case-study-cat' );
										if ( ! empty( $taxonomy_arr ) && ! is_wp_error( $taxonomy_arr ) ) {
											foreach ( $taxonomy_arr as $tax_val ) {
												echo '<a class="post-category" href="javascript:void(0);"><span>' . esc_html( $tax_val->name ) . '</span></a>';
												break;
											}
										}
										if ( get_the_title() ) {
											?>
											<div class="post-title">
												<?php echo get_the_title(); //phpcs:ignore ?>
											</div>
											<?php
										}
										?>
										<a class="btn secondary white" href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php esc_html_e( 'View Case Study', 'ats' );	 ?></a>
									</div>
								</div>
							</li>
							<?php
						} // end while
						wp_reset_postdata();
						?>
					</ul>
					<nav class="navigation pagination">
						<h2 class="screen-reader-text"><?php echo esc_html__( 'Posts navigation' ); ?></h2>
						<div class="nav-links">
							<?php
							$big = 999999999;
							// phpcs:ignore
							echo paginate_links(
								array(
									'base'      => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
									'format'    => '?paged=%#%',
									'current'   => max( 1, get_query_var( 'paged' ) ),
									'total'     => $insight_post->max_num_pages,
									'prev_next' => false,
								)
							);
							?>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</div>
</section>
