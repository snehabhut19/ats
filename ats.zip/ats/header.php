<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ATS
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>  
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
		<!-- fm favicon snippet start - Include this in html head -->

		<!-- Desktop browser favicon -->
		<link rel="icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/inc/favicon/favicon-32x32.png" sizes="32x32" class="light-scheme-icon">
		<link rel="icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/inc/favicon/favicon-48x48.png" sizes="48x48" class="light-scheme-icon">
		<link rel="shortcut icon" type="image/ico" href="<?php echo get_template_directory_uri(); ?>/inc/assets/favicon.ico" class="light-scheme-icon">
		<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
		<link rel="dns-prefetch" href="https://www.youtube.com/">
		<link rel="dns-prefetch" href="https://p.typekit.net/">
		<link rel="dns-prefetch" href="https://use.typekit.net/">
		<link rel="dns-prefetch" href="https://use.typekit.net/ahz3pwz.css">
		<link rel="preconnect" href="https://use.typekit.net/ahz3pwz.css" crossorigin="anonymous">

		<!-- Apple Touch Icon -->
		<link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_template_directory_uri(); ?>/inc/favicon/apple-touch-icon.png">

		<!-- Windows 8.0 -->
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="<?php echo get_template_directory_uri(); ?>/inc/favicon/mstile-144x144.png">

		<!-- Google Fonts -->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Red+Hat+Display:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@700&display=swap" rel="stylesheet">

		<!-- fm favicon snippet end-->
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title><?php wp_title(); ?> <?php bloginfo( 'name' ); ?></title>
		<?php wp_head(); ?>
	</head>
	<?php
	$background_color = get_field( 'background_color' );
	$background_image = get_field( 'background_image' );
	$style            = array();
	if ( ! empty( $background_color ) ) {
		$style[] = 'background-color: ' . $background_color;
	}
	if ( ! empty( $background_color ) ) {
		$style[] = 'background-image: url(' . $background_image . ')';
	}
	?>
	<body <?php body_class(); ?> style="<?php echo implode( "; ", $style ); ?>">
	<?php
	if ( ! function_exists( 'wp_body_open' ) ) {
		/**
		 * After body action hook
		 */
		function wp_body_open() {
			do_action( 'wp_body_open' );
		}
	}
	?>
	<header>
		<div class="header-top-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-4 col-md-8 top-bar-left">
					<?php
					$phone_link = get_field( 'phone_link', 'options' );
					$mail_link  = get_field( 'header_mail', 'options' );
					if ( $phone_link || $mail_link ) :
						if ( $phone_link ) :
							$link_url    = $phone_link['url'];
							$link_title  = $phone_link['title'];
							$link_target = $phone_link['target'] ? $phone_link['target'] : '_self';
							?>
							<a class="phone-number" href="<?php echo esc_url( $link_url ); ?>"  target="<?php echo esc_attr( $link_target ); ?>"><span><?php echo esc_html( $link_title ); ?></span></a>
							<?php
						endif;
						if ( $mail_link ) :
							$link_url    = $mail_link['url'];
							$link_title  = $mail_link['title'];
							$link_target = $mail_link['target'] ? $mail_link['target'] : '_self';
							?>
							<a class="email" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><span><?php echo esc_html( $link_title ); ?></span></a>
							<?php
						endif;
					endif;
					?>
					</div>
					<div class="col-8 col-md-4 text-end">
						<?php
						$cta_link = get_field( 'header_cta', 'options' );
						if ( $cta_link ) :
							$link_url    = $cta_link['url'];
							$link_title  = $cta_link['title'];
							$link_target = $cta_link['target'] ? $cta_link['target'] : '_self';
							?>
							<a class="btn" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
							<?php
						endif;
						?>
					</div>
				</div>
			</div>
		</div>
		<nav class="navbar navbar-expand-lg">
			<div class="container">
			<?php
			$header_logo = get_field( 'header_logo', 'options' );
			if ( $header_logo ) :
				?>
				<div class="col-auto">
					<a class="navbar-brand" href="<?php echo esc_url( get_home_url() ); ?>">
						<img src="<?php echo esc_url( $header_logo['url'] ); ?>"
							alt="<?php echo esc_attr( $header_logo['alt'] ); ?>" />
					</a>
				</div>
				<?php endif; ?>
				<div class="col-auto me-lg-auto">
				<button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-line"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<?php
						if ( has_nav_menu( 'primary' ) ) {
							wp_nav_menu(
								array(
									'theme_location' => 'primary',
									'menu'           => 'primary',
									'menu_class'     => 'navbar-nav',
									'container'      => 'collapse navbar-collapse',
									'container_id'   => 'header-nav',
									'fallback_cb'    => false,
									'depth'          => 0,
									'walker'         => new Ats_Menu_Walker(),
								)
							);
						} else {
							wp_nav_menu(
								array(
									'menu_class' => 'navbar-nav',
									'menu'       => '',
								)
							);
						}
						?>
					</div>
				</div>	
			</div>
		</nav>
	</header>
	<main class="main-content-wrap">
		<!-- main content: BEGIN -->
