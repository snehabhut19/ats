<?php
/**
 * Add functionality
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'ats_plugins_loaded' ) ) {
	/**
	 * ATS theme only works with Advanced Custom Fields Pro.
	 */
	function ats_plugins_loaded() {
		if ( is_admin() || ( 'wp-login.php' === $GLOBALS['pagenow'] ) ) {
			return;
		}

		if ( ! class_exists( 'acf' ) ) {
			$acfexternalurl = 'https://www.advancedcustomfields.com/pro';
			wp_die( sprintf(__( 'It needs <a href="%1s" target="_blank">Advanced Custom Fields Pro</a> to run. Please download and activate it.', 'ats' ), $acfexternalurl ) );// phpcs:ignore
		}
	}
}
add_action( 'init', 'ats_plugins_loaded' );

if ( ! function_exists( 'ats_allow_mime_types' ) ) {
	/**
	 * Allow CSV file type
	 *
	 * @param array $mimes Add Mime Types.
	 */
	function ats_allow_mime_types( $mimes ) {
		$mimes['svg'] = 'image/svg+xml';
		return $mimes;
	}
}
add_filter( 'upload_mimes', 'ats_allow_mime_types' );

if ( ! function_exists( 'add_img_alt_tag_title' ) ) {
	/**
	 * Filter attributes for the current gallery image tag to add 'alt'
	 * data attribute.
	 *
	 * @param array   $attr       image tag attributes.
	 * @param WP_Post $attachment WP_Post object for the attachment.
	 * @return array (maybe) filtered image tag attributes.
	 */
	function add_img_alt_tag_title( $attr, $attachment = null ) {

		$img_title = trim( wp_strip_all_tags( $attachment->post_title ) );

		if ( empty( $attr['alt'] ) ) {
			$attr['alt']   = $img_title;
			$attr['title'] = $img_title;
		}
		return $attr;
	}
}
add_filter( 'wp_get_attachment_image_attributes', 'add_img_alt_tag_title', 10, 2 );

if ( ! function_exists( 'get_image_id' ) ) {
	/**
	 * Retrieves the attachment ID from url.
	 *
	 * @param string $image_url Image URL.
	 */
	function get_image_id( $image_url ) {
		global $wpdb;
		$attachment = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url ) ); // phpcs:ignore

		return $attachment[0];
	}
}

if ( ! function_exists( 'add_alt_tags' ) ) {
	/**
	 * Add IMG alt tag attribute in Post Content.
	 *
	 * @param string $content Image URL.
	 */
	function add_alt_tags( $content ) {

		preg_match_all( '/<img (.*?)\/>/', $content, $images );

		if ( ! empty( $images ) ) {
			foreach ( $images[1] as $index => $value ) {
				preg_match( '@src="([^"]+)"@', $images[1][ $index ], $match );
				$src            = array_pop( $match );
				$image_id       = get_image_id( $src );
				$image_title    = get_the_title( $image_id );
				$image_alt_text = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
				$alt_text       = ( ! empty( $image_alt_text ) && '' !== $image_alt_text ) ? $image_alt_text : $image_title;
				$new_img        = str_replace( '<img', '<img alt="' . $alt_text . '"', $images[0][ $index ] );
				$content        = str_replace( $images[0][ $index ], $new_img, $content );
			}
		}
		return $content;
	}
}
add_filter( 'the_content', 'add_alt_tags', 999 );

/**
 * Placeholder image.
 */
if ( ! function_exists( 'ats_af_placeholder_image' ) ) {
	function ats_af_placeholder_image() {
		$placeholder = get_field( 'placeholder_image', 'option' );
		if ( ! empty( $placeholder ) ) {
			$placeholder_alt = ( isset( $placeholder['alt'] ) && ! empty( $placeholder['alt'] ) ) ? $placeholder['alt'] : ( isset( $placeholder['title'] ) && ! empty( $placeholder['title'] ) ? $placeholder['title'] : '' );
			?>
			<img class="skip-lazy" width="<?php echo $placeholder['sizes']['ats-desktop-width']; ?>" height="<?php echo $placeholder['sizes']['ats-desktop-height']; ?>" src="<?php echo $placeholder['sizes']['ats-desktop']; ?>" srcset="<?php echo $placeholder['sizes']['ats-small-mobile']; ?> 400w, <?php echo $placeholder['sizes']['ats-mobile']; ?> 800w, <?php echo $placeholder['sizes']['ats-tablet']; ?> 1200w, <?php echo $placeholder['sizes']['ats-desktop']; ?> 2000w" sizes="50vw" alt="<?php echo $placeholder_alt; ?>"><?php // phpcs:ignore ?>
			<?php
		}
	}
}

/**
 * Pagination
 */
if ( ! function_exists( 'pagination_bar' ) ) {
	/**
	 * Pagination Bar.
	 *
	 * @param object $custom_query Retrive custom Query.
	 */
	function pagination_bar( $custom_query ) {

		$total_pages = $custom_query->max_num_pages;
		$big         = 999999999; // need an unlikely integer.

		if ( $total_pages > 1 ) {
			$current_page = max( 1, get_query_var( 'paged' ) );

			echo paginate_links( // phpcs:ignore
				array(
					'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
					'format'  => '?paged=%#%',
					'current' => $current_page,
					'total'   => $total_pages,
				)
			);
		}
	}
}

if ( ! function_exists( 'theme_breadcrumb_display' ) ) {
	/**
	 * Display Breadcrumb using below function.
	 */
	function theme_breadcrumb_display() {
		if ( is_front_page() ) {
			return;
		}
		if ( class_exists( 'Theme_Breadcrumb' ) ) {
			$breadcrumb_title_blog = esc_html__( 'Home', 'ats' );
			$breadcrumb_title_home = esc_html__( 'Home', 'ats' );

			$theme_breadcrumb                          = new Theme_Breadcrumb();
			$theme_breadcrumb->opt['static_frontpage'] = false;
			$theme_breadcrumb->opt['url_blog']         = '';
			$theme_breadcrumb->opt['title_blog']       = apply_filters( 'theme_breadcrumb_title_blog', $breadcrumb_title_blog );
			$theme_breadcrumb->opt['title_home']       = apply_filters( 'theme_breadcrumb_title_home', $breadcrumb_title_home );
			$theme_breadcrumb->opt['separator']        = '';
			$theme_breadcrumb->opt['tag_page_prefix']  = '';
			$theme_breadcrumb->opt['singleblogpost_category_display'] = false;

			return $theme_breadcrumb->theme_display_breadcrumb();
		}
	}
}

// Enable shortcode in text field.
add_filter( 'acf/format_value/type=text', 'do_shortcode' );

/**
 * Display Current year.
 *
 * @return void
 */
function display_year() {
	$year = date( 'Y' );
	return $year;
}
add_shortcode( 'year', 'display_year' );
