<?php
/**
 * Register Custom Post types.
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'ats_cpt_teams' ) ) {
	/**
	 * Create Career Custom Post Type
	 */
	function ats_cpt_teams() {

		// Set UI labels for Custom Post Type.
		$labels = array(
			'name'               => _x( 'Team', 'Post Type General Name', 'ats' ),
			'singular_name'      => _x( 'Team', 'Post Type Singular Name', 'ats' ),
			'menu_name'          => __( 'Team', 'ats' ),
			'parent_item_colon'  => __( 'Parent Team', 'ats' ),
			'all_items'          => __( 'Team', 'ats' ),
			'add_new_item'       => __( 'Add New Team', 'ats' ),
			'add_new'            => __( 'Add New', 'ats' ),
			'edit_item'          => __( 'Edit Team', 'ats' ),
			'update_item'        => __( 'Update Team', 'ats' ),
			'search_items'       => __( 'Search Team', 'ats' ),
			'not_found'          => __( 'Not Found', 'ats' ),
			'not_found_in_trash' => __( 'Not found in Trash', 'ats' ),
		);

		// Set other options for Custom Post Type.19,653,926
		$args = array(
			'label'               => __( 'Team', 'ats' ),
			'description'         => __( 'Team', 'ats' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'thumbnail', 'revisions', 'custom-fields', 'editor', 'excerpt' ),
			'menu_icon'           => 'dashicons-groups',
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 23,
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'show_in_rest'        => false,
		);

		// Registering your Custom Post Type.
		register_post_type( 'team', $args );
	}
}
add_action( 'init', 'ats_cpt_teams' );

if ( ! function_exists( 'ats_cpt_case_studies' ) ) {
	/**
	 * Create Career Custom Post Type
	 */
	function ats_cpt_case_studies() {

		// Set UI labels for Custom Post Type.
		$labels = array(
			'name'               => _x( 'Case Studies', 'Post Type General Name', 'ats' ),
			'singular_name'      => _x( 'Case Studies', 'Post Type Singular Name', 'ats' ),
			'menu_name'          => __( 'Case Studies', 'ats' ),
			'parent_item_colon'  => __( 'Parent Case Studies', 'ats' ),
			'all_items'          => __( 'Studies', 'ats' ),
			'add_new_item'       => __( 'Add New Studies', 'ats' ),
			'add_new'            => __( 'Add New', 'ats' ),
			'edit_item'          => __( 'Edit Studies', 'ats' ),
			'update_item'        => __( 'Update Studies', 'ats' ),
			'search_items'       => __( 'Search Studies', 'ats' ),
			'not_found'          => __( 'Not Found', 'ats' ),
			'not_found_in_trash' => __( 'Not found in Trash', 'ats' ),
		);

		// Set other options for Custom Post Type.19,653,926
		$args = array(
			'label'               => __( 'Case Studies', 'ats' ),
			'description'         => __( 'Case Studies', 'ats' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'thumbnail', 'revisions', 'custom-fields', 'editor', 'excerpt' ),
			'menu_icon'           => 'dashicons-smiley',
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 23,
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'show_in_rest'        => false,
			'rewrite' 			=> array( 'slug' => 'case-study', 'with_front' => false, ),
		);

		// Registering your Custom Post Type.
		register_post_type( 'case-studies', $args );

		/**
		 * Case Study Custom Category.
		 */
		$labels = array(
			'name'              => _x( 'Category', 'taxonomy general name', 'ats' ),
			'singular_name'     => _x( 'Category', 'taxonomy singular name', 'ats' ),
			'search_items'      => __( 'Search Category', 'ats' ),
			'all_items'         => __( 'All Category', 'ats' ),
			'parent_item'       => __( 'Parent Category', 'ats' ),
			'parent_item_colon' => __( 'Parent Case Study:', 'ats' ),
			'edit_item'         => __( 'Edit Category', 'ats' ),
			'update_item'       => __( 'Update Category', 'ats' ),
			'add_new_item'      => __( 'Add New Category', 'ats' ),
			'new_item_name'     => __( 'New Case Study Name', 'ats' ),
			'menu_name'         => __( 'Category', 'ats' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => false,
			'show_ui'           => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_in_rest'      => true,
		);

		// Registering your Custom Taxonomy.
		register_taxonomy( 'case-study-cat', array( 'case-studies' ), $args );

	}
}
add_action( 'init', 'ats_cpt_case_studies' );
