<?php
/**
 * Default Footer
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$footer_logo_1    = get_field( 'footer_logo_1', 'option' );
$headline         = get_field( 'heading', 'option' );
$heading_tag      = get_field( 'select_heading_tag', 'option' );
$sub_title        = get_field( 'sub_title', 'option' );
$phone_number     = get_field( 'phone_number', 'option' );
$email            = get_field( 'email', 'option' );
$button           = get_field( 'cta_button', 'option' );
$background_image = get_field( 'background_image', 'option' );
$background_image = ( ! empty( $background_image ) ) ? ' style="background-image:url(' . esc_url( $background_image ) . '); color: #fff;"' : '';
?>

</main><!-- main content : END -->
<footer>
	<?php
	if ( ! empty( $headline ) || ! empty( $sub_title ) || ! empty( $phone_number ) || ! empty( $email ) || ! empty( $cta_button ) || ! empty( $background_image ) ) {
		?>
		<section class="footer-cta-block">
			<div class="container">
				<div class="row m-0" <?php echo $background_image; ?>>
					<div class="col-12 text-center">
						<?php
						if ( ! empty( $headline ) ) {
							echo '<' . esc_attr( $heading_tag ) . ' class="h-3">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';		
						}
						if ( ! empty( $sub_title ) ) {
							?>
							<div class="block-subtitle">
								<?php echo $sub_title; //phpcs:ignore ?>
							</div>
							<?php
						}
						if ( ! empty( $phone_number ) || ! empty( $email ) ) {
							?>
							<div class="phone-email">
								<?php
								if ( $phone_number && ! empty( $phone_number['title'] ) && ! empty( $phone_number['url'] ) ) {
									$number_url    = ( ! empty( $phone_number['url'] ) ) ? $phone_number['url'] : '#';
									$number_title  = $phone_number['title'];
									$number_target = ( $phone_number['target'] ) ? $phone_number['target'] : '_self';
									?>
									<a class="phone-number" href="<?php echo esc_url( $number_url ); ?>" target="<?php echo esc_attr( $number_target ); ?>">
									<?php echo esc_html( $number_title ); ?>
									</a>
									<?php
								}
								if ( $email && ! empty( $email['title'] ) && ! empty( $email['url'] ) ) {
									$email_url    = ( ! empty( $email['url'] ) ) ? $email['url'] : '#';
									$email_title  = $email['title'];
									$email_target = ( $email['target'] ) ? $email['target'] : '_self';
									?>
									<a class="email" href="<?php echo esc_url( $email_url ); ?>" target="<?php echo esc_attr( $email_target ); ?>">
									<?php echo esc_html( $email_title ); ?>
									</a>
									<?php
								}
								?>
							</div>
							<?php
						}
						if ( ! empty( $button ) ) {
							?>
							<div class="cta-button">
								<?php
								if ( $button && ! empty( $button['title'] ) && ! empty( $button['url'] ) ) {
									$button_url    = ( ! empty( $button['url'] ) ) ? $button['url'] : '#';
									$button_title  = $button['title'];
									$button_target = ( $button['target'] ) ? $button['target'] : '_self';
									?>
									<a class="btn"  href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>">
									<?php echo esc_html( $button_title ); ?>
									</a>
									<?php
								}
								?>
							</div>
							<?php
						}
						?>
					</div>
				</div>
			</div>
		</section>
		<?php
	}
	?>
	<div class="footer-section">
		<div class="container">
			<?php
			if ( $footer_logo_1 ) :
				?>
				<div class="row footer-top">
					<div class="col-12 text-center">
					<a class="footer-link-logo" href="<?php echo esc_url( get_home_url() ); ?>">
						<img src="<?php echo esc_url( $footer_logo_1['url'] ); ?>"
							alt="footer-logo" />
					</a>
					</div>
				</div>
				<?php
			endif;
			?>
			<?php
			if ( is_active_sidebar( 'footer-col-1' ) || is_active_sidebar( 'footer-col-2' ) || is_active_sidebar( 'footer-col-3' ) || is_active_sidebar( 'footer-col-4' ) || is_active_sidebar( 'footer-col-5' ) ) :
				?>
				<div class="row footer-middle text-center text-sm-start">
					<?php
					if ( is_active_sidebar( 'footer-col-1' ) ) {
						?>
						<div class="col-xl-3 col-lg-4 col-md-5 col-sm-6">
							<?php dynamic_sidebar( 'footer-col-1' ); ?>
						</div>
						<?php
					}
					if ( is_active_sidebar( 'footer-col-2' ) ) {
						?>
						<div class="col-xl-2 col-md col-sm-6">
							<?php dynamic_sidebar( 'footer-col-2' ); ?>
						</div>
						<?php
					}
					if ( is_active_sidebar( 'footer-col-3' ) ) {
						?>
						<div class="col-xl-2 col-md col-sm-6">
							<?php dynamic_sidebar( 'footer-col-3' ); ?>
						</div>
						<?php
					}
					if ( is_active_sidebar( 'footer-col-4' ) ) {
						?>
						<div class="col-lg col-md-5 col-sm-6 address-col">
							<?php dynamic_sidebar( 'footer-col-4' ); ?>
						</div>
						<?php
					}
					if ( is_active_sidebar( 'footer-col-5' ) ) {
						?>
						<div class="col-12 col-lg col-md-7 contact-col">
							<?php dynamic_sidebar( 'footer-col-5' ); ?>
						</div>
						<?php
					}
					?>
				</div>
				<?php
			endif;
			?>
			<div class="row footer-bottom">
				<div class="col-12 d-flex flex-wrap align-items-center text-center justify-content-center">
					<?php
					$footer_copyright = get_field( 'footer_copyright', 'option' );
					if ( $footer_copyright ) :
						?>
						<span class="copyright"><?php echo $footer_copyright; ?></span>
					<?php endif; ?>
					<?php
					if ( has_nav_menu( 'copyright' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'copyright',
								'menu'           => 'copyright',
								'menu_class'     => 'navbar-nav navigation-links',
								'container'      => 'menu-container',
								'container_id'   => 'navbarNav',
								'fallback_cb'    => false,
								'depth'          => 0,
							)
						);
					}
					?>
					<?php
					$brand_link   = get_field( 'brand_link', 'option' );
					if ( $brand_link ) {
						?>
						<div class="brand-link ms-lg-auto">
							<?php
							if ( $brand_link && ! empty( $brand_link['title'] ) && ! empty( $brand_link['url'] ) ) {
								$button_url    = ( ! empty( $brand_link['url'] ) ) ? $brand_link['url'] : '#';
								$button_title  = $brand_link['title'];
								$button_target = ( $brand_link['target'] ) ? $brand_link['target'] : '_self';
								?>
								<span>Website by
								<a href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>"><?php echo esc_html( $button_title ); ?>
								</a>
								</span>
								<?php
							}
							?>
						</div>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>  

