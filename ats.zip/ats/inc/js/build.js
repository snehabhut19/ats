/* ==================================================================================== *
 *
 * DOM-based Routing
 * Based on http://goo.gl/EUTi53 by Paul Irish
 * & https://roots.io/sage/
 *
 * Only fires on body classes that match. If a body class contains a dash,
 * replace the dash with an underscore when adding it to the object below.
 *
 * .noConflict()
 * The routing is enclosed within an anonymous function so that you can
 * always reference jQuery with $, even when in .noConflict() mode.
 *
 * ==================================================================================== *
 *
 * TweenMax
 * By GreenStock
 * https://greensock.com/tweenmax
 * https://ihatetomatoes.net/wp-content/uploads/2016/07/GreenSock-Cheatsheet-4.pdf
 *
 * ==================================================================================== */

(function ($) {
	// Use this variable to set up the common and page specific functions. If you
	// rename this variable, you will also need to rename the namespace below.
	var atstheme = {
		// All pages
		'common': {
			init: function () {

				$('.count').each(function () {
					$(this).prop('Counter', 0).animate({
						Counter: $(this).text()
					}, {
						duration: 3000,
						easing: 'swing',
						step: function (now) {
							$(this).text(Math.ceil(now));
						}
					});
				});
				$(document).ready(function () {

					// Sticky js.	
					var scrollPos = $(window).scrollTop();
					var mini_header_height = $('.header-top-bar').height();
					$('header .navbar').css({ 'top': mini_header_height });
					$('.header-top-bar').css({ 'top': '0' });
					$(window).scroll(function () {
						if ($(window).scrollTop() >= 100) {
							$('header').addClass('sticky');
							$('.header-top-bar').css({ 'top': - mini_header_height });
							$('header .navbar').css({ 'top': '0' });
						}
						else {
							$('header').removeClass('sticky');
							$('.header-top-bar').css({ 'top': '0px' });
							$('header .navbar').css({ 'top': mini_header_height });
						}

					});

					// Add Swiper in Logos.				
					/***** Swiper slider using params *****/
					$('[data-slider-options]').each(function () {
						var _this = $(this),
							sliderOptions = _this.attr('data-slider-options');
						if (typeof (sliderOptions) !== 'undefined' && sliderOptions !== null) {
							sliderOptions = $.parseJSON(sliderOptions);
							var swiperObj = new Swiper(_this, sliderOptions);
						}
					});

					let swiperObjs = [];
					// Case studies Taxonomy Filter
					$('ul.case-studies-catogories li a.check-box').on('click', function (event) {
						//event.preventDefault();
						if ($(window).width() < 991) {
							$('ul.case-studies-catogories li a.active').removeClass('active');
							$(this).parent().find('a.check-box').toggleClass("active");
						} else {
							$('ul.case-studies-catogories li a.active').removeClass('active');
							$(this).addClass('active');

						}
						var Id = $(this).attr('data-id');

						$.ajax({
							url: ats_vars.ajaxurl,
							type: 'POST',	
							data: {
								'action': 'case_studies_filter',
								category: Id
							},
							beforeSend: function (data) {
								$('.spinner').show();
								$('.navigation').hide();
								$('.case-studies-list').hide();
							},
							success: function (data) {
								// success javascript code
								setTimeout(function(){
									$('.filter-content .case-studies-list').remove();
									$('.filter-content .row').html(data).css({ opacity: 0 }).fadeTo("normal",1);
									$('.spinner').hide();  
								}, 1000);
							},
						});
					});
				});

				/***** Swiper slider using params *****/
				$('[data-slider-options]').each(function () {
					var _this = $(this),
						sliderOptions = _this.attr('data-slider-options'),
						sliderid = _this.attr('data-id');

					if (typeof (sliderOptions) !== 'undefined' && sliderOptions !== null) {
						sliderOptions = $.parseJSON(sliderOptions);
						//console.log(sliderOptions);
						var swiperObj = new Swiper('.' + sliderid, sliderOptions);
					}
				});

				//Header Height JS.

				setTimeout(function () {
					setTopSpaceHeight();
				}, 300);


				//Resize height.
				$(window).resize(function () {
					var mini_header_height = $('.header-top-bar').height();
					$('header .navbar').css({ 'top': mini_header_height });
					$('.header-top-bar').css({ 'top': '0' });
					setTopSpaceHeight();
				});

				/****** Get top space header height ******/
				function getHeaderHeight() {
					var headerHeight = 0;
					if ($('.header-top-bar').length) {
						headerHeight = headerHeight + $('.header-top-bar').innerHeight();
					}
					if ($('header nav.navbar').length) {
						headerHeight = headerHeight + $('header nav.navbar').innerHeight();
					}
					if ($('.left-modern-header .left-modern-sidebar').length) {
						headerHeight = headerHeight + $('.left-modern-header .left-modern-sidebar').innerHeight();
					}
					return headerHeight;
				}

				/****** Get window width ******/
				function getWindowWidth() {
					return $(window).width();
				}

				/****** Get top space height ******/
				function setTopSpaceHeight() {

					if (!$('header').hasClass('sticky') && ($('.top-space-margin').length)) {
						var headerHeight = getHeaderHeight(),
							menuBreakPoint = 991;
						if ($('.top-space-margin').length) {
							$('.top-space-margin').css('margin-top', headerHeight);
						}
						if ($('.top-space-padding').length) {
							$('.top-space-padding').css('padding-top', headerHeight);
						}
						if ($('.ipad-top-space-margin').length) {
							if (getWindowWidth() <= menuBreakPoint) {
								$('.ipad-top-space-margin').css('margin-top', headerHeight);
							} else {
								$('.ipad-top-space-margin').css('margin-top', 'inherit');
							}
						}
					}
				}

				/** Mega Menu */

				$(".mobile-icon").on("click", function () {
					console.log('hello');
					if ($(this).parent('.menu-item-has-children').hasClass('show')) {
						$(this).parent('.menu-item-has-children ').removeClass('show');
						$(this).next('.mega-menu-wrapper').slideUp();
					} else {
						$(this).parent('.menu-item-has-children').addClass('show');
						$(this).parent('.menu-item-has-children').siblings().removeClass('show');
						$(this).parent('.menu-item-has-children').siblings().find('.mega-menu-wrapper').slideUp();
						$(this).next('.mega-menu-wrapper').slideDown();
					}
				});
			},
			finalize: function () {
			}
		},
		// Home/Index page example - if WordPress, 'index' will need to be changed to 'home'
		'home': {
			init: function () {
				// JavaScript to be fired on the home page


			},
			finalize: function () {
				// JavaScript to be fired on the home page, after the init JS
			}
		},
		// About us page, note the change from about-us to about_us.
		'about_us': {
			init: function () {
				// JavaScript to be fired on the about us page
			}
		}
		// ...
	};

	// The routing fires all common scripts, followed by the page specific scripts.
	// Add additional events for more control over timing e.g. a finalize event
	var UTIL = {
		fire: function (func, funcname, args) {
			var fire;
			var namespace = atstheme;
			funcname = (funcname === undefined) ? 'init' : funcname;
			fire = func !== '';
			fire = fire && namespace[func];
			fire = fire && typeof namespace[func][funcname] === 'function';

			if (fire) {
				namespace[func][funcname](args);
			}
		},
		loadEvents: function () {
			// Fire common init JS
			UTIL.fire('common');

			// Fire page-specific init JS, and then finalize JS
			$.each(document.body.className.replace(/-/g, '_').split(/\s+/), function (i, classnm) {
				UTIL.fire(classnm);
				UTIL.fire(classnm, 'finalize');
			});

			// Fire common finalize JS
			UTIL.fire('common', 'finalize');
		}
	};

	// Load Events
	$(document).ready(UTIL.loadEvents);

})(jQuery); // Fully reference jQuery after this point.
