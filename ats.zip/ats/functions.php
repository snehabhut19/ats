<?php
/**
 * Ats Includes
 * The $ats_af_includes array determines the code library included into the site.
 *
 * Add funtions.php - WP specific config
 * root-wrapper.php - Theme wrapper config
 * extras.php - Additional functions
 * optimisation.php - Optimisation functions
 *
 * @package ATS
 */

define( 'ATS_AF_THEME_DIR', get_template_directory() );
define( 'ATS_AF_THEME_DIR_URI', get_template_directory_uri() );
define( 'ATS_AF_THEME_LIB', ATS_AF_THEME_DIR . '/lib' );

$ats_af_includes = array(
	'lib/root-wrapper.php',
	'lib/extras.php',
	'lib/ats-custom-post-types.php',
);

foreach ( $ats_af_includes as $file ) {
	if ( ! $filepath = locate_template( $file ) ) { // phpcs:ignore
		trigger_error( sprintf( __( 'Error locating %s for inclusion', 'ats' ), $file ), E_USER_ERROR ); // phpcs:ignore
	}

	require_once $filepath;
}
unset( $file, $filepath );

if ( ! function_exists( 'ats_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * @since Ats 1.0
	 *
	 * @return void
	 */
	function ats_setup() {
		/**
		 * Register Featured Image Support
		 */
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'ats-desktop', 1920, '', array( 'center', 'center' ) );
		add_image_size( 'ats-tablet', 1200, '', array( 'center', 'center' ) );
		add_image_size( 'ats-mobile', 767, '', array( 'center', 'center' ) );
		add_image_size( 'ats-small-mobile', 400, '' );

		/**
		 * Text Domain
		 */
		load_theme_textdomain( 'ats', ATS_AF_THEME_DIR . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * This theme does not use a hard-coded <title> tag in the document head,
		 * WordPress will provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/**
		 * Add post-formats support.
		 */
		add_theme_support(
			'post-formats',
			array(
				'link',
				'aside',
				'gallery',
				'image',
				'quote',
				'status',
				'video',
				'audio',
				'chat',
			)
		);

		/**
		 * Register Navigations
		 */
		register_nav_menus(
			array(
				'primary'   => __( 'Primary Menu', 'ats' ),
				'copyright' => __( 'Copyright Menu', 'ats' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for full and wide align images.
		add_theme_support( 'align-wide' );
	}
}
add_action( 'after_setup_theme', 'ats_setup' );

/**
 * Resgister and include Script
 * Stylesheet to Header and Footer
 */

if ( ! function_exists( 'register_load_scripts' ) ) {
	/**
	 * Register Scripts
	 */
	function register_load_scripts() {
		global $wp_query;
		wp_register_script( 'ats-vendors', get_template_directory_uri() . '/dist/vendors.min.js', array( 'jquery', 'jquery-ui-core' ), wp_get_theme()->get( 'Version' ), true );
		wp_register_script( 'ats-scripts', get_template_directory_uri() . '/dist/main.min.js', array( 'jquery', 'ats-vendors', 'jquery-ui-core' ), wp_get_theme()->get( 'Version' ), true );

		wp_enqueue_script( 'ats-scripts' );

		wp_localize_script(
			'ats-scripts',
			'ats_vars',
			array(
				'ajaxurl'      => site_url() . '/wp-admin/admin-ajax.php',
				'posts'        => wp_json_encode( $wp_query->query_vars ),
				'current_page' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1,
				'max_page'     => $wp_query->max_num_pages,
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'register_load_scripts' );

if ( ! function_exists( 'register_load_stylesheets' ) ) {
	/**
	 * Register Stylesheet
	 */
	function register_load_stylesheets() {
		wp_register_style( 'ats-font', 'https://use.typekit.net/uxr2mjb.css', array(), wp_get_theme()->get( 'Version' ), 'screen', false );
		wp_register_style( 'bootstrap', get_template_directory_uri() . '/inc/css/vendor/bootstrap.css', array(), '5.0.2', 'screen', false );
		wp_register_style( 'swiper', get_template_directory_uri() . '/inc/css/vendor/swiper-bundle.min.css', array(), '8.0.7', 'screen', false );
		wp_register_style( 'styles', get_template_directory_uri() . '/dist/main.min.css', array(), wp_get_theme()->get( 'Version' ), 'screen' );

		wp_enqueue_style( 'ats-font' );
		wp_enqueue_style( 'bootstrap' );
		wp_enqueue_style( 'swiper' );
		wp_enqueue_style( 'styles' );
	}
}
add_action( 'wp_enqueue_scripts', 'register_load_stylesheets' );

if ( ! function_exists( 'widgets_init' ) ) {
	/**
	 * Register Sidebars
	 */
	function widgets_init() {

		register_sidebar(
			array(
				'name'          => __( 'Footer Column 1', 'ats' ),
				'id'            => 'footer-col-1',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<span class="footer-title">',
				'after_title'   => '</span>',
			)
		);

		register_sidebar(
			array(
				'name'          => __( 'Footer Column 2', 'ats' ),
				'id'            => 'footer-col-2',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<span class="footer-title">',
				'after_title'   => '</span>',
			)
		);

		register_sidebar(
			array(
				'name'          => __( 'Footer Column 3', 'ats' ),
				'id'            => 'footer-col-3',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<span class="footer-title">',
				'after_title'   => '</span>',
			)
		);

		register_sidebar(
			array(
				'name'          => __( 'Footer Column 4', 'ats' ),
				'id'            => 'footer-col-4',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<span class="footer-title">',
				'after_title'   => '</span>',
			)
		);

		register_sidebar(
			array(
				'name'          => __( 'Footer Column 5', 'ats' ),
				'id'            => 'footer-col-5',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<span class="footer-title">',
				'after_title'   => '</span>',
			)
		);
	}
}
add_action( 'widgets_init', __NAMESPACE__ . '\\widgets_init' );

/**
 * Blog post time ago text.
 *
 * @return string Timestamp.
 */
function meks_time_ago() {
	return human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) . ' ' . __( 'ago' );
}

/**
 * Add page name class in body tag.
 *
 * @param  [type] $classes Class object.
 * @return $classes Return page name class.
 */
function wp_body_classes( $classes ) {
	global $post;
	if ( is_page() ) {
		$classes[] = $post->post_name;
	}
	return $classes;
}
add_filter( 'body_class', 'wp_body_classes' );

/**
 * Case Study Filters ajax callback function.
 *
 * @return void
 */
function case_studies_filter() {
	$catslug = $_POST['category']; //phpcs:ignore

	if ( '' === $catslug ) {
		return;
	}
	$args = array(
		'post_type'   => 'case-studies',
		'post_status' => 'publish',
		'tax_query'   => array(
			array(
				'taxonomy'         => 'case-study-cat',
				'field'            => 'term_id',
				'terms'            => $catslug,
				'include_children' => true,
				'operator'         => 'IN',
			),
		),
	);

	$projects = new WP_Query( $args );

	$response = '';

	if ( $projects->have_posts() ) {
		?>
		<div class="col-12 position-relative">
		<div class="spinner"><div class="spinner-speeding"></div></div>
			<ul class="case-studies-list">
				<?php
				while ( $projects->have_posts() ) {
					$projects->the_post();
					if ( has_post_thumbnail() ) {
						$select_image = get_the_post_thumbnail();
					} else {
						$select_image = '<img src="' . ATS_AF_THEME_DIR_URI . '/inc/assets/placeholder-image.jpg" />';
					}
					?>
					<li>
						<div class="related-case-studies-details">
							<div class="feature-image">
								<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php echo $select_image; ?></a>
							</div>
							<div class="related-case-studies-content">
								<?php
								$taxonomy_arr = get_the_terms( get_the_ID(), 'case-study-cat' );
								if ( ! empty( $taxonomy_arr ) && ! is_wp_error( $taxonomy_arr ) ) {
									foreach ( $taxonomy_arr as $tax_val ) {
										echo '<a class="post-category" href="javascript:void(0);"><span>' . esc_html( $tax_val->name ) . '</span></a>';
										break;
									}
								}
								if ( get_the_title() ) {
									?>
									<div class="post-title">
										<?php echo get_the_title(); //phpcs:ignore ?>
									</div>
									<?php
								}
								?>
								<a class="btn secondary white" href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php esc_html_e( 'View Case Study', 'ats' ); ?></a>
							</div>
						</div>
					</li>
					<?php
				} // end while.
				wp_reset_postdata();
				?>
			</ul>
		</div>
		<?php
	} else {
		$response = 'No Post Found';
	}
	if ( ! empty( $response ) ) {
		?>
		<div class="col-12 no-post">
			<?php
			echo $response; //phpcs:ignore
			?>
		</div>
		<?php
	}
	exit;
}
add_action( 'wp_ajax_case_studies_filter', 'case_studies_filter' );
add_action( 'wp_ajax_nopriv_case_studies_filter', 'case_studies_filter' );

/**
 * Populate ACF select field options with Gravity Forms forms.
 *
 * @param [type] $field Get feild object.
 * @return $field Populate all gravity form data.
 */
function acf_populate_gf_forms_ids( $field ) {
	if ( class_exists( 'GFFormsModel' ) ) {
		$choices = array();

		foreach ( \GFFormsModel::get_forms() as $form ) {
			$choices[ $form->id ] = $form->title;
		}

		$field['choices'] = $choices;
	}

	return $field;
}
add_filter( 'acf/load_field/name=select_gravity_form', 'acf_populate_gf_forms_ids' );

if ( file_exists( ATS_AF_THEME_LIB . '/mega-menu.php' ) ) :
	require_once ATS_AF_THEME_LIB . '/mega-menu.php';
endif;
