<?php
/**
 * Template part for displaying posts content.
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php

if ( have_rows( 'blog_flexible' ) ) {
	while ( have_rows( 'blog_flexible' ) ) :
		the_row();
		$layout_section = get_row_layout();

		switch ( $layout_section ) {
			case 'blog_hero':
				$template_name = str_replace( '_', '-', $layout_section );
				get_template_part( 'template-parts/acf-flexible/' . $template_name );
				break;
			default:
				break;
		}
	endwhile;
}
if ( have_rows( 'blog_flexible' ) ) {
	?>
	<section class="blog-detail">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xxl-7 col-xl-8 col-lg-9">
					<?php
					while ( have_rows( 'blog_flexible' ) ) :
						the_row();
						$layout_section = get_row_layout();

						switch ( $layout_section ) {
							case 'text_block':
							case 'quote_block':
							case 'single_image':
								$template_name = str_replace( '_', '-', $layout_section );
								get_template_part( 'template-parts/acf-flexible/' . $template_name );
								break;
							default:
								break;
						}
					endwhile;
					?>
				</div>
			</div>
		</div>
	</section>
	<?php
}

if ( have_rows( 'blog_flexible' ) ) {
	while ( have_rows( 'blog_flexible' ) ) :
		the_row();
		$layout_section = get_row_layout();

		switch ( $layout_section ) {
			case 'blog_teaser':
				$template_name = str_replace( '_', '-', $layout_section );
				get_template_part( 'template-parts/acf-flexible/' . $template_name );
				break;
			default:
				break;
		}
	endwhile;
}

