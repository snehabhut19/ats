<?php
/**
 * Template part for displaying posts content.
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$category = get_the_category();
?>
<div class="col">
	<?php
	if ( has_post_thumbnail() ) {
		?>
		<div class="feature-image">
			<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php the_post_thumbnail(); ?></a>
		</div>
		<?php
	} else {
		?>
		<div class="feature-image">
			<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>">
				<img src="<?php echo ATS_AF_THEME_DIR_URI ?>/inc/assets/placeholder-image.jpg" />
			</a>
		</div>
		<?php
	}
	if ( ! empty( $category ) ) {
		?>
		<div class="post-category">
			<?php echo $category[0]->name; //phpcs:ignore?>
		</div>
		<?php
	}
	if ( get_the_title() ) {
		?>
		<div class="post-title h-5">
			<?php echo get_the_title(); //phpcs:ignore ?>
		</div>
		<?php
	}
	?>
	<div class="post-content">
		<?php
		if ( has_excerpt( get_the_ID() ) ) {
				echo get_the_excerpt( get_the_ID() ); //phpcs:ignore
		} else {
			echo substr( strip_tags( get_the_content( get_the_ID() ) ), 0, 100 ); //phpcs:ignore
		}
		?>
	</div>

	<a class="btn secondary" href="<?php echo get_the_permalink(); ?>"><?php esc_html_e( 'Mehr lesen', 'ats' ); ?></a>

</div>
