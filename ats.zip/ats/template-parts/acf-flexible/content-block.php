<?php
/**
 * Content Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$heading_tag       = get_sub_field( 'select_heading_tag' );
$text              = get_sub_field( 'text' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $headline ) || ! empty( $text ) ) {
	?>
	<section class="content-block<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
			<div class="row">
				<div class="col-12 section-title">
					<?php
					if ( ! empty( $headline ) ) {
						echo '<' . esc_attr( $heading_tag ) . ' class="h-2">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';
					}
					if ( ! empty( $text ) ) {
						?>
						<div class="block-content">
							<?php echo $text; //phpcs:ignore ?>
						</div>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</section>
	<?php
}
