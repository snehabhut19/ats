<?php
/**
 * Related Team Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$heading_tag       = get_sub_field( 'select_heading_tag' );
$related_team      = get_sub_field( 'related_team' );
$view_more_button  = get_sub_field( 'view_more_button' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $headline ) || ( $related_team ) ) {
	?>
	<section class="related-team-block<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
			<?php
			if ( ! empty( $headline ) ) {
				?>
				<div class="row">
					<div class="col-12 text-center section-title">
						<?php
						echo '<' . esc_attr( $heading_tag ) . ' class="h-5">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';
						?>
					</div>
				</div>
				<?php
			}
			if ( $related_team ) {
				?>
				<div class="row related-team-warp">
					<?php
					foreach ( $related_team as $post ) {
						setup_postdata( $post );
                        $position = get_field( 'position' );
						if ( has_post_thumbnail() ) {
							$select_image = get_the_post_thumbnail();
						} else {
							$select_image = '<img src="' . ATS_AF_THEME_DIR_URI . '/inc/assets/placeholder-image.jpg" />';
						}
						?>
						<div class="col-4">
							<div class="related-team-details">
								<div class="feature-image">
									<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php echo $select_image; ?></a>
								</div>
								<div class="related-team-content">
									<div class="post-category">
										<?php echo $position; ?>
									</div>
									<?php
									if ( get_the_title() ) {
										?>
										<div class="post-title">
											<?php echo get_the_title(); //phpcs:ignore ?>
										</div>
										<?php
									}
									?>
									<a class="btn secondary white" href="<?php echo get_the_permalink(); ?>"><?php esc_html_e( 'View Team' ); ?></a>
								</div>
							</div>
						</div>
						<?php
					}
					wp_reset_postdata();
					?>
				</div>
				<?php
			}
			if ( ! empty( $view_more_button ) ) {
				?>
				<div class="view-more-button text-center">
					<?php
					if ( $view_more_button && ! empty( $view_more_button['title'] ) && ! empty( $view_more_button['url'] ) ) {
						$button_url    = ( ! empty( $view_more_button['url'] ) ) ? $view_more_button['url'] : '#';
						$button_title  = $view_more_button['title'];
						$button_target = ( $view_more_button['target'] ) ? $view_more_button['target'] : '_self';
						?>
						<a class="btn"  href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>">
						<?php echo esc_html( $button_title ); ?>
						</a>
						<?php
					}
					?>
				</div>
				<?php
			}
			?>
		</div>
	</section>
	<?php
}

