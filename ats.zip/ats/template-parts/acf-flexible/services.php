<?php
/**
 * Services Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$select_text_class = get_sub_field( 'select_text_class' );
$heading_tag       = get_sub_field( 'select_heading_tag' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $headline ) || have_rows( 'services' ) ) {
	?>
	<section class="our-services<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
			<?php
			if ( ! empty( $headline ) ) {
				?>
				<div class="row">
					<div class="col-12 <?php echo $select_text_class; ?>">
						<?php
						echo '<' . esc_attr( $heading_tag ) . ' class="h-5">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';
						?>
					</div>
				</div>
				<?php
			}
			if ( have_rows( 'services' ) ) {
				?>
				<div class="row row-cols-1 row-cols-xl-5 row-cols-lg-3 row-cols-md-3 row-cols-sm-2 justify-content-xl-center">
						<?php
						while ( have_rows( 'services' ) ) :
							the_row();
							$logo        = get_sub_field( 'logo' );
							$_title      = get_sub_field( 'title' );
							$text        = get_sub_field( 'text' );
							$button      = get_sub_field( 'cta_button' );
							$hover_image = get_sub_field( 'hover_image' );
							$button_url  = ( ! empty( $button['url'] ) ) ? $button['url'] : '#';
							?>
							<div class="col icon-with-text">
								<?php
								if ( ! empty( $logo) || ! empty( $hover_image ) ) {
									if ( ! empty( $button_url ) ) {
										?>
										<a href="<?php echo $button_url; ?>" >
										<?php
									}
									?>
									<div class="services-logo">
										<img class="default-icon" src="<?php echo $logo['url']; //phpcs:ignore ?>" alt="<?php echo esc_attr( $logo['alt'] ); ?>" width="<?php echo $logo['sizes']['ats-desktop-width']; ?>" height="<?php echo $logo['sizes']['ats-desktop-height']; ?>" srcset="<?php echo $logo['sizes']['ats-small-mobile']; ?> 400w, <?php echo $logo['sizes']['ats-mobile']; ?> 800w, <?php echo $logo['sizes']['ats-tablet']; ?> 1200w, <?php echo $logo['sizes']['ats-desktop']; ?> 2000w" sizes="50vw" /><?php
										if ( ! empty( $hover_image ) ) {
											?><img class="hover-icon" src="<?php echo $hover_image['url']; //phpcs:ignore ?>" alt="<?php echo esc_attr( $hover_image['alt'] ); ?>" width="<?php echo $hover_image['sizes']['ats-desktop-width']; ?>" height="<?php echo $hover_image['sizes']['ats-desktop-height']; ?>" srcset="<?php echo $hover_image['sizes']['ats-small-mobile']; ?> 400w, <?php echo $hover_image['sizes']['ats-mobile']; ?> 800w, <?php echo $hover_image['sizes']['ats-tablet']; ?> 1200w, <?php echo $hover_image['sizes']['ats-desktop']; ?> 2000w" sizes="50vw" />
											<?php
										}
										?>
									</div>
									<?php
									if ( ! empty( $button_url ) ) {
										?>
										</a>
										<?php
									}
								}
								if ( ! empty( $_title ) ) {
									?>
									<div class="block-title">
										<?php echo $_title; //phpcs:ignore ?>
									</div>
									<?php
								}
								if ( ! empty( $text ) ) {
									?>
									<div class="block-content">
										<?php echo $text; //phpcs:ignore ?>
									</div>
									<?php
								}
								if ( ! empty( $button ) ) {
									?>
									<div class="service-button">
										<?php
										if ( $button && ! empty( $button['title'] ) && ! empty( $button['url'] ) ) {
											$button_url    = ( ! empty( $button['url'] ) ) ? $button['url'] : '#';
											$button_title  = $button['title'];
											$button_target = ( $button['target'] ) ? $button['target'] : '_self';
											?>
											<a class="btn secondary"  href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>">
											<?php echo esc_html( $button_title ); ?>
											</a>
											<?php
										}
										?>
									</div>
									<?php
								}
								?>
							</div>
							<?php
						endwhile;
						?>
					</div>
				<?php
			}
			?>
		</div>
	</section>
	<?php
}