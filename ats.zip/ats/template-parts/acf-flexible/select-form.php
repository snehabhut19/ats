<?php 
/**
 * Select Form Block.
 *
 * @package ATS
 */
$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$selected_form     = get_sub_field( 'select_gravity_form' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}
?>
<section class="enquiry-form<?php echo esc_attr( $margin_class ); ?>">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<?php echo do_shortcode('[gravityform id="' . $selected_form . '" title="true"]'); ?>
			</div>
		</div>
	</div>
</section>