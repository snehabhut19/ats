<?php
/**
 * Infographic Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$heading_tag       = get_sub_field( 'select_heading_tag' );
$sub_title         = get_sub_field( 'sub_title' );
$text              = get_sub_field( 'text' );
$headline_tag      = get_sub_field( 'headline_tag' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $headline ) || ! empty( $sub_title ) || ! empty( $text ) || have_rows( 'counter_box' ) ) {
	?>
	<section class="infographic-block<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
			<?php
			if ( ! empty( $headline ) || ! empty( $sub_title ) || ! empty( $text ) ) {
				?>
				<div class="row">
					<div class="col-12 section-title">
						<?php
						if ( ! empty( $sub_title ) ) {
							?>
							<?php echo '<' . esc_attr( $headline_tag ) . ' class="block-subtitle h-5">' . esc_html( $sub_title ) . '</' . esc_attr( $headline_tag ) . '>'; ?>
							<?php
						}
						if ( ! empty ( $headline ) ) { //phpcs:ignore
							echo '<' . esc_attr( $heading_tag ) . ' class="h-2">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';
						}
						if ( ! empty( $text ) ) {
							?>
							<div class="block-content">
								<?php echo $text; //phpcs:ignore ?>
							</div>
							<?php
						}
						?>
					</div>
				</div>
				<?php
			}
			if ( have_rows( 'counter_box' ) ) {
				?>
				<div class="row row-cols-1 row-cols-lg-3 row-cols-md-2 justify-content-center infographic-block-warp">
						<?php
						while ( have_rows( 'counter_box' ) ) {
							the_row();
							?>
							<div class="col">
								<div class="infographic-block-bg">
								<?php
								$_title         = get_sub_field( 'title' );
								$sub_title      = get_sub_field( 'sub_title' );
								$counter_number = get_sub_field( 'counter_number' );
								$suffix         = get_sub_field( 'suffix' );
								if ( ! empty( $_title ) ) {
									?>
									<div class="block-content">
										<?php echo $_title; //phpcs:ignore ?>
									</div>
									<?php
								}
								if ( ! empty( $sub_title ) ) {
									?>
									<div class="sub-title-block">
										<?php echo $sub_title; //phpcs:ignore ?>
									</div>
									<?php
								}
								if ( ! empty( $counter_number ) ) {
									?>
									<div class="counter-number count">
										<?php echo $counter_number; //phpcs:ignore ?>
									</div>
									<?php
								}
								if ( ! empty( $suffix ) ) {
									?>
									<div class="suffix">
										<?php echo $suffix; //phpcs:ignore ?>
									</div>
									<?php
								}
								?>
							</div>
							</div>
							<?php
						}
						?>
				</div>
				<?php
			}
			?>
		</div>
	</section>
	<?php
}

