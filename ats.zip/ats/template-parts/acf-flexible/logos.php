<?php
/**
 * Logo Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$heading_tag       = get_sub_field( 'select_heading_tag' );
$count             = count( get_sub_field( 'logos' ) );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}
if ( $count > 4 ) {
	$swiper = ' swiper mySwiper';
} else {
	$swiper = '';
}


if ( ! empty( $headline ) || have_rows( 'logos' ) ) {
	?>
	<section class="logo-block<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
		<?php
		if ( ! empty( $headline ) ) {
			?>
			<div class="row">
				<div class="col-12 text-center section-title">
					<?php
					echo '<' . esc_attr( $heading_tag ) . ' class="h-5">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';
					?>
				</div>
			</div>
			<?php
		}
		if ( have_rows( 'logos' ) ) {
			?>
			<div class="row mx-0 swiper" data-slider-options='{ "slidesPerView": 2, "spaceBetween": 20, "autoplay": { "delay": 4000, "disableOnInteraction": false }, "pagination": { "el": ".swiper-pagination", "clickable": "true" }, "breakpoints": { "1200": { "slidesPerView": 4, "spaceBetween": 20 }, "768": { "slidesPerView": 3,"spaceBetween": 30 }, "576": { "slidesPerView": 2, "spaceBetween": 20 } }, "watchOverflow": "true" }' data-id="swiper">
				<div class="swiper-wrapper p-0">
					<?php
					while ( have_rows( 'logos' ) ) :
						the_row();
						$logo = get_sub_field( 'logo' );
						?>
						<div class="swiper-slide client-logo-warp">
							<?php
							if ( ! empty( $logo ) ) {
								?>
								<div class="client-logo">
									<img src="<?php echo $logo['url']; //phpcs:ignore ?>" alt="<?php echo esc_attr( $logo['alt'] ); ?>" width="<?php echo $logo['sizes']['ats-desktop-width']; ?>" height="<?php echo $logo['sizes']['ats-desktop-height']; ?>" srcset="<?php echo $logo['sizes']['ats-small-mobile']; ?> 400w, <?php echo $logo['sizes']['ats-mobile']; ?> 800w, <?php echo $logo['sizes']['ats-tablet']; ?> 1200w, <?php echo $logo['sizes']['ats-desktop']; ?> 2000w" sizes="50vw" />
								</div>
								<?php
							}
							?>
						</div>
						<?php
					endwhile;
					?>
				</div>	
			</div>
			<?php
		}
		?>
		</div>
	</section>
	<?php
}
