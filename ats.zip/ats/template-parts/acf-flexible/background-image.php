<?php
/**
 * Background Image Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$background_image  = get_sub_field( 'background_image' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $background_image ) ) {
	?>
	<section class="background-image-block<?php echo esc_attr( $margin_class ); ?>">
		<div class="container-fluid">
			<img src="<?php echo $background_image['url']; //phpcs:ignore ?>" alt="<?php echo esc_attr( $background_image['alt'] ); ?>" width="<?php echo $background_image['sizes']['ats-desktop-width']; ?>" height="<?php echo $background_image['sizes']['ats-desktop-height']; ?>" srcset="<?php echo $background_image['sizes']['ats-small-mobile']; ?> 400w, <?php echo $background_image['sizes']['ats-mobile']; ?> 800w, <?php echo $background_image['sizes']['ats-tablet']; ?> 1200w, <?php echo $background_image['sizes']['ats-desktop']; ?> 2000w" sizes="100vw" />
		</div>
	</section>
	<?php
}

