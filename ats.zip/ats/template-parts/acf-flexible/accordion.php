<?php
/**
 * Accordion Block.
 *
 * @package ATS
 */

global $overview_tab_unique_id;

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$heading_tag       = get_sub_field( 'select_heading_tag' );
$header_top_margin = get_sub_field( 'header_top_margin' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $headline ) || have_rows( 'accordion' ) ) {
	?>
	<section class="accordion-block<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
			<div class="row m-0 accordion-warp">
				<div class="col-12">
					<?php
					if ( ! empty( $headline ) ) {
						echo '<' . esc_attr( $heading_tag ) . ' class="accordion-section-title">' . esc_html( $headline ) . '</' . esc_attr( $heading_tag ) . '>';
					}
					if ( have_rows( 'accordion' ) ) {
						$overview_tab_unique_id = ! empty( $overview_tab_unique_id ) ? $overview_tab_unique_id : 1;
						$overview_tab_id        = 'collapses';
						$overview_tab_id       .= '-' . $overview_tab_unique_id;
						$overview_tab_unique_id++;
						$i = 1;
						?>
						<div class="accordion" id="accordion-<?php echo $overview_tab_unique_id; ?>">
							<?php
							while ( have_rows( 'accordion' ) ) {
								the_row();
								$_title = get_sub_field( 'title' );
								$text   = get_sub_field( 'text' );
								if ( $i == 1 ) {
									$collapsed = '';
									$area      = 'true';
									$show      = ' show';
								} else {
									$collapsed = ' collapsed';
									$area      = 'false';
									$show      = '';
								}
								?>
								<div class="accordion-item">
									<?php
									if ( ! empty( $_title ) ) {
										?>
										<div class="accordion-header" id="headings-<?php echo $i; //phpcs:ignore ?>">
											<button class="accordion-title accordion-button<?php echo $collapsed;?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $overview_tab_id; ?>-<?php echo $i; ?>" aria-expanded="<?php echo $area; ?>" aria-controls="<?php echo $overview_tab_id; ?>-<?php echo $i; ?>">
											<?php echo $_title; //phpcs:ignore ?>
											</button>
										</div>
										<?php
									}
									if ( ! empty( $text ) ) {
										?>
										<div id="<?php echo $overview_tab_id;  ?>-<?php echo $i; ?>" class="accordion-collapse collapse<?php echo $show; ?>" aria-labelledby="headings-<?php echo $i; //phpcs:ignore ?>" data-bs-parent="#accordion-<?php echo $overview_tab_unique_id; ?>">
											<div class="accordion-body">
												<?php echo $text; //phpcs:ignore ?>
											</div>
										</div>
										<?php
									}
									?>
								</div>
								<?php
								$i++;
							}
							?>
						</div>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</section>
	<?php
}
