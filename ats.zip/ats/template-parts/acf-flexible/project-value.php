<?php
/**
 * Project Value Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$price_lable       = get_sub_field( 'price_lable' );
$heading_tag       = get_sub_field( 'select_heading_tag' );

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $price_lable ) || have_rows( 'information' ) ) {
	?>
	<section class="price-value<?php echo esc_attr( $margin_class ); ?>">
		<div class="container">
			<div class="row m-0 price-value-warp">
				<div class="col-12 price-value-title">
					<?php
					if ( ! empty ( $price_lable ) ) { //phpcs:ignore
						echo '<' . esc_attr( $heading_tag ) . ' class="h-3">' .  $price_lable 	. '</' . esc_attr( $heading_tag ) . '>';
					}
					?>
				</div>
				<div class="col-12 p-0">
					<div class="row row-cols-1 row-cols-xl-4 row-cols-lg-3 row-cols-sm-2 m-0 price-value-info">
						<?php
						if ( have_rows( 'information' ) ) {
							while ( have_rows( 'information' ) ) {
								the_row();
								$_title    = get_sub_field( 'title' );
								$sub_title = get_sub_field( 'sub_title' );
								?>
								<div class="col">
									<?php
									if ( ! empty( $_title ) ) {
										?>
										<div class="block-title">
											<?php
											echo $_title;
											?>
										</div>
										<?php
									}
									if ( ! empty( $sub_title ) ) {
										?>
										<div class="block-subtitle">
											<?php
											echo $sub_title;
											?>
										</div>
										<?php
									}
									?>
								</div>
								<?php
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
}
