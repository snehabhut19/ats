<?php
/**
 * Homepage Hero Banner Block.
 *
 * @package ATS
 */

$margin_class = '';

$header_top_margin = get_sub_field( 'header_top_margin' );
$headline          = get_sub_field( 'heading' );
$heading_tag       = get_sub_field( 'select_heading_tag' );
$sub_title         = get_sub_field( 'sub_title' );
$text              = get_sub_field( 'text' );
$button            = get_sub_field( 'cta_button' );
$image             = get_sub_field( 'image' );
$heading_tags      = get_sub_field( 'heading_tags' );
$background_image  = get_sub_field( 'background_image' );
$background_image  = ( ! empty( $background_image ) ) ? ' style="background-image:url(' . esc_url( $background_image ) . '); color: #fff;"' : '';

if ( true === $header_top_margin ) {
	$margin_class = ' top-space-margin';
}

if ( ! empty( $headline ) || ! empty( $sub_title ) || ! empty( $text ) || ! empty( $cta_banner ) || ! empty( $image ) || ! empty( $background_image ) ) {
	?>
	<section class="homage-hero-banner<?php echo esc_attr( $margin_class ); ?>"<?php echo $background_image; ?>>
		<div class="container">
			<div class="row align-items-center">
				<?php
				if ( ! empty( $headline ) || ! empty( $sub_title ) || ! empty( $text ) || ! empty( $cta_banner ) ) {
					?>
					<div class="col-xxl-8 col-xl-9 col-lg-10 d-flex flex-column">
						<?php
						if ( ! empty( $sub_title ) ) {
							echo '<' . esc_attr( $heading_tag ) . ' class="block-subtitle">' . $sub_title . '</' . esc_attr( $heading_tag ) . '>';
						}
						if ( ! empty ( $headline ) ) { //phpcs:ignore
							echo '<' . esc_attr( $heading_tags ) . ' class="h-3">' . $headline . '</' . esc_attr( $heading_tags ) . '>';
						}
						if ( ! empty( $text ) ) {
							?>
							<div class="block-content">
								<?php echo $text; //phpcs:ignore ?>
							</div>
							<?php
						}
						if ( ! empty( $button ) ) {
							?>
							<div class="cta-button">
								<?php
								if ( $button && ! empty( $button['title'] ) && ! empty( $button['url'] ) ) {
									$button_url    = ( ! empty( $button['url'] ) ) ? $button['url'] : '#';
									$button_title  = $button['title'];
									$button_target = ( $button['target'] ) ? $button['target'] : '_self';
									?>
									<a class="btn"  href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>">
									<?php echo esc_html( $button_title ); ?>
									</a>
									<?php
								}
								?>
							</div>
							<?php
						}
						?>
					</div>
					<?php
				}
				if ( ! empty( $image ) ) {
					?>
					<div class="col-6 image-block">
						<img src="<?php echo $image['url']; //phpcs:ignore ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" width="<?php echo $image['sizes']['ats-desktop-width']; ?>" height="<?php echo $image['sizes']['ats-desktop-height']; ?>" srcset="<?php echo $image['sizes']['ats-small-mobile']; ?> 400w, <?php echo $image['sizes']['ats-mobile']; ?> 800w, <?php echo $image['sizes']['ats-tablet']; ?> 1200w, <?php echo $image['sizes']['ats-desktop']; ?> 2000w" sizes="50vw" />
					</div>
					<?php
				}
				?>
			</div>
		</div>
	</section>
	<?php
}


