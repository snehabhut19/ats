<?php
/**
 * Display Blog Page.
 *
 * @package ATS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
