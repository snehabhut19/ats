<?php
/**
 * Template part for displaying page content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( get_the_content() ) {
	?>
	<section class="main-content-wrap top-space-margin">	
		<div class="container">
		<div class="row">
			<div class="col-12">
			<?php the_content(); ?>
			</div>
		</div>
		</div>
	</section>
	<?php
}

if ( have_rows( 'page_flexible' ) ) {
	while ( have_rows( 'page_flexible' ) ) :
		the_row();
		$layout_section = get_row_layout();

		switch ( $layout_section ) {
			case 'image_hero_banner':
			case 'homepage_hero_banner':
			case 'services':
			case 'logos':
			case 'infographic_block':
			case 'accordion':
			case 'related_case_studies':
			case 'content_block':
			case 'background_image':
			case 'content_block':
			case 'select_form':
			case 'related_team':
				$template_name = str_replace( '_', '-', $layout_section );
				get_template_part( 'template-parts/acf-flexible/' . $template_name );
				break;
			default:
				break;
		}
	endwhile;
}
