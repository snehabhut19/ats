<?php
/**
 * The template part for displaying a message that posts cannot be found
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="content-none">
	<div class="container">
		<div class="row">
			<div class="col-12 not-found">
				<p><?php echo esc_html__( 'Sorry, but you are looking for something that isn\'t here.', 'ats' ); ?></p>
			</div>
		</div>
	</div>
</section>
