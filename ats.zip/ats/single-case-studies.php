<?php
/**
 * Single page for Case Study Template.
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$case_study_archive_button = get_field( 'case_study_archive_button', 'option' );

?>
<section class="single-image-hero-banner top-space-margin">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6 img-item-content">	
			<div class="case-category h-5">
				<?php
				$terms = get_the_terms( get_the_ID() , 'case-study-cat' );
				if( ! empty( $terms ) ) {
					foreach ( $terms as $term ) {
						?>
						<span><?php echo $term->name; ?></span>
						<?php
					}
				}
				?>
				</div>
				<?php
				if ( get_the_title() ) {
					?>
					<h1 class="post-title h-2">
						<?php echo get_the_title(); //phpcs:ignore ?>
					</h1>
					<?php
				}
				?>
			</div>
			<div class="col-lg-6 d-flex justify-content-end image-block">
				<?php
				if ( has_post_thumbnail() ) {
					?>
					<div class="feature-image">
						<?php the_post_thumbnail(); ?>
					</div>
					<?php
				} else {
					?>
					<div class="feature-image">
						<img src="<?php echo ATS_THEME_DIR_URI ?>/inc/assets/placeholder-image.jpg" />
					</div>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</section>

<?php
if ( have_rows( 'case_study_flexible' ) ) {
	while ( have_rows( 'case_study_flexible' ) ) :
		the_row();
		$layout_section = get_row_layout();

		switch ( $layout_section ) {
			case 'content_block':
			case 'related_case_studies':
			case 'project_value':
			case 'background_image':
				$template_name = str_replace( '_', '-', $layout_section );
				get_template_part( 'template-parts/acf-flexible/' . $template_name );
				break;
			default:
				break;
		}	
	endwhile;
}

if ( ! empty( $case_study_archive_button ) ) {
	?>
	<section class="case-study-archive-btn ">
		<div class="container">
			<div class="row">
				<div class="col-12 text-center back-cta-button">
					<?php
					if ( $case_study_archive_button && ! empty( $case_study_archive_button['title'] ) && ! empty( $case_study_archive_button['url'] ) ) {
						$button_url    = ( ! empty( $case_study_archive_button['url'] ) ) ? $case_study_archive_button['url'] : '#';
						$button_title  = $case_study_archive_button['title'];
						$button_target = ( $case_study_archive_button['target'] ) ? $case_study_archive_button	['target'] : '_self';
						?>
						<a class="btn"  href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>">
						<?php echo esc_html( $button_title ); ?>
						</a>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</section>
	<?php
}