<?php
/**
 * Single page for Team Template.
 *
 * @package ATS
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$position            = get_field( 'position' );
$team_archive_button = get_field( 'team_archive_button', 'option' );
?>
<section class="team-content top-space-margin">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 d-flex image-block">
				<?php
				if ( has_post_thumbnail() ) {
					?>
					<div class="feature-image">
						<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>"><?php the_post_thumbnail(); ?></a>
					</div>
					<?php
				} else {
					?>
					<div class="feature-image">
						<a href="<?php echo get_the_permalink(); // phpcs:ignore ?>">
							<img src="<?php echo ATS_THEME_DIR_URI ?>/inc/assets/placeholder-image.jpg" />
						</a>
					</div>
					<?php
				}
				?>
			</div>
			<div class="col-lg-5 img-item-content">
				<?php
				if ( ! empty( $position ) ) {
					?>
					<h2 class="block-subtitle h-5">
						<?php
						echo $position;
						?>
					</h2>
					<?php
				}
				if ( get_the_title() ) {
					?>
					<h1 class="h-2">
						<?php echo get_the_title(); //phpcs:ignore ?>
				</h1>
					<?php
				}
				?>
				<div class="block-content">
					<?php
						the_content( get_the_ID() ); //phpcs:ignore
					?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
if ( ! empty( $team_archive_button ) ) {
	?>
	<section class="team-btn">
		<div class="container">
			<div class="row">
				<div class="col-12 back-cta-button text-center">
					<?php
					if ( $team_archive_button && ! empty( $team_archive_button['title'] ) && ! empty( $team_archive_button['url'] ) ) {
						$button_url    = ( ! empty( $team_archive_button['url'] ) ) ? $team_archive_button['url'] : '#';
						$button_title  = $team_archive_button['title'];
						$button_target = ( $team_archive_button['target'] ) ? $team_archive_button['target'] : '_self';
						?>
						<a class="btn"  href="<?php echo esc_url( $button_url ); ?>" target="<?php echo esc_attr( $button_target ); ?>">
						<?php echo esc_html( $button_title ); ?>
						</a>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</section>
	<?php
}




